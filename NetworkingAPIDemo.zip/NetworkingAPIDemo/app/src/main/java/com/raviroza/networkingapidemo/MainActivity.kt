package com.raviroza.networkingapidemo

import android.app.ProgressDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        try {
            Thread(Runnable {
                //val snack = Snackbar.make(textView1,"Loading Website",Snackbar.LENGTH_INDEFINITE)
                //snack.animationMode = Snackbar.LENGTH_INDEFINITE
                //snack.show()
                val httpURLConnection =
                    URL("http://www.raviroza.com/").openConnection() as HttpURLConnection
                val data = httpURLConnection.inputStream.bufferedReader().readText()
                Log.d("myerror", data.length.toString())
                runOnUiThread()
                {
                    textView1.text = "data length  : ${data.length}"
                    webView1.settings.javaScriptEnabled=true
                    webView1.loadData(data,"text/html","text/html")
                    //webView1.loadUrl("http://www.raviroza.com")
                    //snack.setText("Loaded")
                    //snack.dismiss()
                }
            }).start()

        } catch (e: Exception) {
            Log.e("myerror", e.toString())
            textView1.text = "error " + e.toString()
        }
    }
}