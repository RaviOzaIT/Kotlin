package com.raviroza.networkingapidemo

import android.app.ProgressDialog
import android.content.Context
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        try {
            val connectivityManager =
                getSystemService(Context.CONNECTIVITY_SERVICE)
                        as ConnectivityManager

            val activeNetworkInfo = connectivityManager.activeNetworkInfo
            var status = ""
            if(activeNetworkInfo != null) {
                status = "network : ${activeNetworkInfo.extraInfo}\n"
                status += "type name : ${activeNetworkInfo.typeName}\n"
                status += "detail state : ${activeNetworkInfo.detailedState}\n"
                status += "is availabe : ${activeNetworkInfo.isAvailable}\n"
                status += "is connected : ${activeNetworkInfo.isConnected}"

                txtNetworkState.text = status
            }
            else
            {
                txtNetworkState.text = "no network"
            }


            Thread(Runnable {
                //val snack = Snackbar.make(textView1,"Loading Website",Snackbar.LENGTH_INDEFINITE)
                //snack.animationMode = Snackbar.LENGTH_INDEFINITE
                //snack.show()
                val httpURLConnection =
                    URL("http://www.raviroza.com/").openConnection() as HttpURLConnection
                val data = httpURLConnection.inputStream.bufferedReader().readText()
                Log.d("myerror", data.length.toString())
                runOnUiThread()
                {
                    textView1.text = "data length  : ${data.length}"
                    webView1.settings.javaScriptEnabled=true
                    webView1.loadData(data,"text/html","UTF-8")
                    //webView1.loadUrl("http://www.raviroza.com")
                    //snack.setText("Loaded")
                    //snack.dismiss()
                }
            }).start()

        } catch (e: Exception) {
            Log.e("myerror", e.toString())
            textView1.text = "error " + e.toString()
        }
    }
}