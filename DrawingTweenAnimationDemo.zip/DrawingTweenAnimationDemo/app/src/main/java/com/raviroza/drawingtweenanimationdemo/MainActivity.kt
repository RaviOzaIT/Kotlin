package com.raviroza.drawingtweenanimationdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.animation.AnimationUtils
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnRotate.setOnClickListener()
        {
            val anim = AnimationUtils.loadAnimation(this,R.anim.rotate)
            imageView.startAnimation(anim)
            //btnRotate.startAnimation(anim)
        }
        btnAlpha.setOnClickListener()
        {
            val anim = AnimationUtils.loadAnimation(this,R.anim.alpha)
            imageView.startAnimation(anim)
            //btnRotate.startAnimation(anim)
        }
        btnTranslate.setOnClickListener()
        {
            val anim = AnimationUtils.loadAnimation(this,R.anim.translate)
            imageView.startAnimation(anim)
            //btnRotate.startAnimation(anim)
        }
        btnScale.setOnClickListener()
        {
            val anim = AnimationUtils.loadAnimation(this,R.anim.scale)
            imageView.startAnimation(anim)
            //btnRotate.startAnimation(anim)
        }
    }
}