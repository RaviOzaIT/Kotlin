package com.raviroza.notificationdemo

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnNoti.setOnClickListener()
        {
            //displayNotification()
            simpleNotification()
        }
    }
    fun simpleNotification()
    {
        // https://www.techotopia.com/index.php/An_Android_8_Notifications_Kotlin_Tutorial

        var nm = getSystemService(Context.NOTIFICATION_SERVICE)
                as NotificationManager

        val intent = Intent(this, DetailsOfNotification::class.java)
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)

        val channelID = "raviroza.apps.notifications"

        val notification = Notification.Builder(this,channelID)
            //.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setSmallIcon(R.drawable.ic_baseline_notifications_24)
            .setContentTitle("Example Notification")
            .setContentText("This is an  example notification.")
            .setContentIntent(pendingIntent)
            .setChannelId(channelID)
            .build()
        nm.notify(1, notification)
    }
    fun displayNotification() {
        val notiManager : NotificationManager
        var notiChannel : NotificationChannel
        val builder     : NotificationCompat.Builder
        val channelId   = "raviroza.apps.notifications"
        val description = "Test notification"

        // Class to notify the user of events that happen.
        // This is how you tell the user that something has happened in the background.
        notiManager = getSystemService(NOTIFICATION_SERVICE)
                        as NotificationManager

        // intent and pending intent to display details of notification
        // the notification is clicked, thiss intent will come into action
        val intent = Intent(this, DetailsOfNotification::class.java)

        val pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)

        // check if android version is > oreo (API-26) or not
        // notification channel is required in android oreo and above version
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {
            notiChannel = NotificationChannel(channelId,description,NotificationManager.IMPORTANCE_HIGH)
            notiChannel.enableVibration(true)
            notiChannel.enableLights(true)
            notiChannel.lightColor = Color.BLUE
            notiManager.createNotificationChannel(notiChannel)

            builder = NotificationCompat.Builder(this, channelId)
                .setSmallIcon(R.drawable.ic_baseline_notifications_24)
                .setContentTitle("My Notification Title text")
                .setContentText("My Notification Content text")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
            Log.d("rro","> oreo")
        }
        else
        {
            // notification without notification channel
            builder = NotificationCompat.Builder(this)
                    .setSmallIcon(R.drawable.ic_baseline_notifications_24)
                    .setContentTitle("Notification title")
                    .setContentText("Notification Content")
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                    .setContentIntent(pendingIntent)
                    .setAutoCancel(true)
            Log.d("rro","< oreo")
        }
        notiManager.notify(1,builder.build())
    }

}