package com.raviroza.radiobuttongroupdemo

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.Exception

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button2.setOnClickListener()
        {
            Toast.makeText(this,it.toString(),Toast.LENGTH_LONG).show()
        }
        radioColorGroup.setOnCheckedChangeListener { group, checkedId ->
            if(checkedId == R.id.radRed)
            {
                Toast.makeText(this,radRed.text.toString(),Toast.LENGTH_LONG).show()
                mainContainer.setBackgroundColor(Color.RED)
            }
            else if(checkedId == R.id.radGreen)
            {
                Toast.makeText(this,radGreen.text.toString(),Toast.LENGTH_LONG).show()
                mainContainer.setBackgroundColor(Color.GREEN)
            }
            else if(checkedId == R.id.radBlue)
            {
                Toast.makeText(this,radBlue.text.toString(),Toast.LENGTH_LONG).show()
                mainContainer.setBackgroundColor(Color.BLUE)
            }
            else if(checkedId == R.id.radReset)
            {
                Toast.makeText(this,radBlue.text.toString(),Toast.LENGTH_LONG).show()
                mainContainer.setBackgroundColor(Color.WHITE)
            }
        }
        try {
            //var v: ConstraintLayout = findViewById(R.id.mainContainer)
            var b = Button(this)
            b.text = "added"
            //v.addView(b)

            mainContainer.addView(b)
            b.setOnClickListener()
            {
                Toast.makeText(this,"hi",Toast.LENGTH_LONG).show()
            }
        }
        catch (e:Exception)
        {
            Toast.makeText(this,e.toString(),Toast.LENGTH_LONG).show()
        }

    }
}