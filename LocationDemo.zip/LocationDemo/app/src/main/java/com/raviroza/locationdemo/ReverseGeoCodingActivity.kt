package com.raviroza.locationdemo

import android.location.Geocoder
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_reversegecoding.*


class exceReverseGeoCodingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reversegecoding)

        try {
            btnGetAddresses.setOnClickListener()
            {
                val v = getAddress(
                    txtLatitutde.text.toString().toDouble(),
                    txtLongitude.text.toString().toDouble(),
                    txtMaxResults.text.toString().toInt()
                )
                txtAddresses.text = v.toString()
            }
        } catch (e: Exception) {
            Log.e("myerror", e.toString())
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show()
        }
    }

    private fun getAddress(lat: Double, lng: Double, maxResults: Int): String {
        val geocoder = Geocoder(this)
        val list = geocoder.getFromLocation(lat, lng, maxResults)
        //return list[0].getAddressLine(0)
        var t = ""
        for (x in list) {
            t += "Address : ${x.getAddressLine(0)} " +
                    "\nAdmin Area/State : ${x.adminArea} " +
                    "\nCountry : ${x.countryCode}-${x.countryName} "
            t += "\n-------------------------------------\n"
        }
        return t
    }
}