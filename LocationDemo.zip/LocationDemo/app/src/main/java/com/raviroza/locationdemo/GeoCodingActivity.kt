package com.raviroza.locationdemo

import android.content.Intent
import android.location.Address
import android.location.Geocoder
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_gecoding.*


class GeoCodingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gecoding)

        try {
            btnGetLocationLatLong.setOnClickListener()
            {
                val v = getAddress(txtAddressInfo.text.toString(), 1)
                txtLatitutde.text = v.latitude.toString()
                txtLongitude.text = v.longitude.toString()
            }
            btnMapLocation.setOnClickListener()
            {
                val geoURI = java.lang.String.format("geo:%f,%f", txtLatitutde.text, txtLongitude.text)
                val geo: Uri = Uri.parse(geoURI)
                val geoMap = Intent(Intent.ACTION_VIEW, geo)
                startActivity(geoMap)
            }
        } catch (e: Exception) {
            Log.e("myerror", e.toString())
            Toast.makeText(this, e.toString(), Toast.LENGTH_SHORT).show()
        }
    }

    private fun getAddress(add: String, maxResults: Int): Address
    {
        val geocoder = Geocoder(this)
        //val list = geocoder.getFromLocation(lat, lng, maxResults)
        val list = geocoder.getFromLocationName(add, maxResults)
        return list[0]
    }
}