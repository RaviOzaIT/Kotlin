package com.raviroza.locationdemo

import android.content.Context
import android.content.Intent
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat.getSystemService
import kotlinx.android.synthetic.main.activity_getcurrentlocation.*

class GetCurrentLocationActivity : AppCompatActivity(), LocationListener
{
    private lateinit var locationManager: LocationManager
    private lateinit var location : Location
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_getcurrentlocation)

        try {
            btnGetCurrentLocation.setOnClickListener()
            {
                getLocationInfo()
            }
            btn1GeoCoding.setOnClickListener()
            {
                startActivity(Intent(this,GeoCodingActivity::class.java))
            }
            btn2RevGeoCoding.setOnClickListener()
            {
                startActivity(Intent(this,ReverseGeoCodingActivity::class.java))
            }
        }
        catch (e:Exception)
        {
            Log.e("myerror",e.toString())
            Toast.makeText(this,e.toString(),Toast.LENGTH_SHORT).show()
        }

    }
    private fun getLocationInfo() {
        try {
            locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                1000,
                5f,
                this)
        } catch (e: Exception) {
            Log.e("myerror", e.toString())
        }
    }

    override fun onLocationChanged(location: Location) {
        txtLocation.text = "Latitude: \n" + location.latitude + " \nLongitude: \n" + location.longitude
        //val v = getAddress(location.latitude,location.longitude)
        //Toast.makeText(this,v.toString(),Toast.LENGTH_SHORT).show()
    }
    private fun getAddress(lat: Double, lng: Double): String {
        val geocoder = Geocoder(this)
        val list = geocoder.getFromLocation(lat, lng, 5)
        //return list[0].getAddressLine(0)
        var t=""
        for (x in list) {
            t +=  x.getAddressLine(0)+ "\n"+ x.adminArea
        }
        return t
    }
//    private fun getAddress(lat: Double, lng: Double): String {
//        val geocoder = Geocoder(this)
//        val list = geocoder.getFromLocation(lat, lng, 1)
//        return list[0].getAddressLine(0)
//    }
}
//class getRROLocation() : LocationListener
//{
//    private lateinit var locationManager: LocationManager
//    private lateinit var location : Location
//    init {
//        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
//        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,5f,this)
//    }
//    override fun onLocationChanged(location: Location) {
//        Log.e("rro","Latitude: \n" + location.latitude + " \nLongitude: \n" + location.longitude)
//        this.location = location
//        val v = getAddress(location.latitude,location.longitude)
//        Log.e("rro-address",v.toString())
//    }
//    private fun getAddress(lat: Double, lng: Double): String {
//        val geocoder = Geocoder(this)
//        val list = geocoder.getFromLocation(lat, lng, 5)
//        //return list[0].getAddressLine(0)
//        var t=""
//        for (x in list) {
//            t +=  x.getAddressLine(0)+ "\n"+ x.adminArea
//        }
//        return t
//    }
//}