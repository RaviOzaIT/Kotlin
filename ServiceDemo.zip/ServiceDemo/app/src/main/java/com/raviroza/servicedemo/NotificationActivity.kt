package com.raviroza.servicedemo

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class NotificationActivity : AppCompatActivity(){

    protected override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        /*
        setContentView(R.layout.activity_notification)
        buttonStart = findViewById<View>(R.id.buttonStart) as Button?
        buttonStop = findViewById<View>(R.id.buttonStop) as Button?
        buttonStart!!.setOnClickListener(this)
        buttonStop!!.setOnClickListener(this)
        notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager?
        builder = Builder(this)
    }

    fun sendNotification(view: View?) {
        //Get an instance of NotificationManager//
        //NotificationCompat.Builder builder = new NotificationCompat.Builder(this);
        builder.setSmallIcon(android.R.drawable.ic_delete)
        builder.setContentTitle("My notification")
        builder.setContentText("Hello World!")

        //Create the intent that�ll fire when the user taps the notification//
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/"))
        val pendingIntent: PendingIntent = PendingIntent.getActivity(this, 0, intent, 0)

        //builder.addAction(R.drawable.ic_launcher, "Open", pendingIntent);
        builder.setContentIntent(pendingIntent)

        // Gets an instance of the NotificationManager service//
        notificationManager.notify(0, builder.build())
    }

    override fun onClick(src: View) {
        when (src.id) {
            R.id.buttonStart -> {
                notificationManager.notify(0, builder.build())
                startService(Intent(this, MyService::class.java))
            }
            R.id.buttonStop -> {
                stopService(Intent(this, MyService::class.java))
                notificationManager.cancel(0)
            }
        }
    }*/
    }
}