package com.raviroza.servicedemo

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnStartService.setOnClickListener()
        {
            var intent:Intent = Intent(this,MyService::class.java)
            //startService(Intent(this, MyService::class.java))
            startService(intent)
            Toast.makeText(this,"start",Toast.LENGTH_SHORT).show()
        }
        btnStopService.setOnClickListener()
        {
            var intent:Intent = Intent(this,MyService::class.java)
            //stopService(Intent(this, MyService::class.java))
            stopService(intent)
            Toast.makeText(this,"stop",Toast.LENGTH_SHORT).show()
        }
    }
}