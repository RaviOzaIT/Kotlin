package com.raviroza.servicedemo

import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.IBinder
import android.util.Log
import android.widget.Toast

class MyService : Service()
{
    lateinit var myPlayer: MediaPlayer

    override fun onBind(intent: Intent): IBinder? {
        return null
    }
    override fun onCreate() {
        Log.d("rro","service:on-create")
        Toast.makeText(this, "Service Created", Toast.LENGTH_LONG).show()
        myPlayer = MediaPlayer.create(this, R.raw.pyar_kar_liya_to_kya)
        //myPlayer.setLooping(false) // Set looping
    }

    override fun onStart(intent: Intent, startid: Int) {
        Log.d("rro","service:on-start")
        Toast.makeText(this, "Service Started", Toast.LENGTH_LONG).show()
        myPlayer.start()
    }

    override fun onDestroy() {
        Log.d("rro","service:on-stop")
        Toast.makeText(this, "Service Stopped", Toast.LENGTH_LONG).show()
        myPlayer.stop()
    }
}