package com.raviroza.dialogdemo

import android.content.DialogInterface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.raviroza.dialogdemo.R

import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setTitle("Dialog Demo")
        btnTestDialog.setOnClickListener()
        {
            val alertDialog = AlertDialog.Builder(this)
            alertDialog.setTitle("Start Game")
            alertDialog.setMessage("Please decide, what to do with your game ?")
            alertDialog.setIcon(android.R.drawable.btn_star_big_on)

            alertDialog.setNeutralButton("Neutral", DialogInterface.OnClickListener { dialog, which ->
                textView.text = "Neutral Selected -> $which"
                Toast.makeText(this,"Selected", Toast.LENGTH_LONG).show()
            })

            alertDialog.setPositiveButton("OK",DialogInterface.OnClickListener { dialog, which ->
                textView.text = "OK Selected -> $which"
                Toast.makeText(this,"OK",Toast.LENGTH_LONG).show()
            })

            alertDialog.setNegativeButton("Cancel", DialogInterface.OnClickListener { dialog, which ->
                textView.text = "Cancel Selected -> $which"
                Toast.makeText(this,"Cancel",Toast.LENGTH_LONG).show()
            })
            alertDialog.show()
        }
    }
}