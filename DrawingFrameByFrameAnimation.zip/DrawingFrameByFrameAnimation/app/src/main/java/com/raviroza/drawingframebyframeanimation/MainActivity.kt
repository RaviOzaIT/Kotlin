package com.raviroza.drawingframebyframeanimation

import android.animation.ValueAnimator
import android.graphics.drawable.AnimationDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageView.setBackgroundResource(R.drawable.my_animation)
        var drawableAnimation : AnimationDrawable = imageView.background as AnimationDrawable
        //animation.isOneShot = true



        btnStart.setOnClickListener()
        {
            drawableAnimation.start()
            imageView.animate()
        }
        btnStop.setOnClickListener()
        {
            drawableAnimation.stop()
        }
    }
}