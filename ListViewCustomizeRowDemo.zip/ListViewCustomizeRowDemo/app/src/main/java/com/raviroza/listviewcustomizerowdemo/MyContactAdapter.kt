package com.raviroza.listviewcustomizerowdemo

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import kotlinx.android.synthetic.main.layout_list_view_row.view.*

class MyContactAdapter
    (
      val context : Activity,
      val myContactList : ArrayList<MyContact>
    )
    : ArrayAdapter <MyContact> (context,0, myContactList)
{
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View
    {

        val inflater = context.layoutInflater
        val rowView = inflater.inflate(R.layout.layout_list_view_row, null, true)

        rowView.ContactName.text = myContactList.get(position).ContactName
        rowView.ContactImage.setImageResource (myContactList.get(position).ContactImageID)
        rowView.ContactNumber.text = myContactList.get(position).ContactNumber

        /*val name = rowView.findViewById(R.id.ContactName) as TextView
        val image = rowView.findViewById(R.id.ContactImage) as ImageView
        val number = rowView.findViewById(R.id.ContactNumber) as TextView

        name.text = myContactList.get(position).ContactName
        image.setImageResource(myContactList.get(position).ContactImageID)
        number.text = myContactList.get(position).ContactNumber*/
        return rowView
    }
}