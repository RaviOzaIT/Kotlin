package com.raviroza.listviewcustomizerowdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var arrayList: ArrayList<MyContact> = ArrayList<MyContact>()

        /*arrayList.add(MyContact(R.drawable.ic_launcher_background ,"ravi oza ","98986"))
        arrayList.add(MyContact(R.drawable.ic_launcher_background,"amit oza","823800"))
        */
        for(i in 1..20)
        {
            arrayList.add(MyContact(R.drawable.ic_launcher_background ,"Name : $i","98$i 78 $i 546"))
        }

        var myAdap = MyContactAdapter(this,arrayList)

        listView1.adapter = myAdap

    }
}