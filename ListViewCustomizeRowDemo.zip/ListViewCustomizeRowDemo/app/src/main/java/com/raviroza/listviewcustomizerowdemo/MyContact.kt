package com.raviroza.listviewcustomizerowdemo
public class MyContact (
    val ContactImageID:Int,
    val ContactName:String,
    val ContactNumber:String)
