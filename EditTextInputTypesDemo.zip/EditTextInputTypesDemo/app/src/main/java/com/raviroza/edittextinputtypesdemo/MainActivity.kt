package com.raviroza.edittextinputtypesdemo

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.MultiAutoCompleteTextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var cities = arrayOf("Jamnagar","Ahmedabad","Surat","Baroda","Kolkata")
        var adapter = ArrayAdapter(this,android.R.layout.simple_dropdown_item_1line,cities)
        edAutoComplete.setAdapter(adapter)

        var hobbies = arrayOf("play","read","walk","talk","listen","not listen")
        var hadapter = ArrayAdapter(this,android.R.layout.simple_list_item_checked,hobbies)
        edAutoCompleteMulti.setAdapter(hadapter)
        edAutoCompleteMulti.setTokenizer(MultiAutoCompleteTextView.CommaTokenizer())


        edEmailAddress.addTextChangedListener(object : TextWatcher
        {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                if (!android.util.Patterns.EMAIL_ADDRESS.matcher(s).matches())
                {
                    edEmailAddress.setError("Invalid Email Address")
                }
            }
            override fun afterTextChanged(s: Editable?) {
            }

        });

        var c = Calendar.getInstance()
        edDate.setOnClickListener()
        {
            DatePickerDialog(this,DatePickerDialog.OnDateSetListener { view, year, month, dayOfMonth ->
                edDate.setText("$dayOfMonth/${month+1}/$year")
            }
                ,c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show()
        }

        edTime.setOnClickListener()
        {
            TimePickerDialog(this,TimePickerDialog.OnTimeSetListener { view, hourOfDay, minute ->
                edTime.setText("$hourOfDay:$minute")

            },c.get(Calendar.HOUR),c.get(Calendar.MINUTE),false).show()
        }
    }
}