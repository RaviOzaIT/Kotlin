package com.raviroza.checkboxdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    var choices = mutableSetOf("")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        chkBaseBall.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                choices.add(buttonView.text.toString())
                setChoices()
            } else {
                choices.remove(buttonView.text.toString())
                setChoices()
            }
        }
        chkChess.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                choices.add(buttonView.text.toString())
                setChoices()
            } else {
                choices.remove(buttonView.text.toString())
                setChoices()
            }
        }
        chkCricket.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                choices.add(buttonView.text.toString())
                setChoices()
            } else {
                choices.remove(buttonView.text.toString())
                setChoices()
            }
        }
        chkKabbadi.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                choices.add(buttonView.text.toString())
                setChoices()
            } else {
                choices.remove(buttonView.text.toString())
                setChoices()
            }
        }
        chkSoftBall.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                choices.add(buttonView.text.toString())
                setChoices()
            } else {
                choices.remove(buttonView.text.toString())
                setChoices()
            }
        }
        chkVolley.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                choices.add(buttonView.text.toString())
                setChoices()
            } else {
                choices.remove(buttonView.text.toString())
                setChoices()
            }
        }
    }

    fun setChoices() {
        var ch = ""
        lblChoiceList.text = ""
        for (x in choices)
            ch += x + " "
        lblChoiceList.text = ch.toString()
    }
}