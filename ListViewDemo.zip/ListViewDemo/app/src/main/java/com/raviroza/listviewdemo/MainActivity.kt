package com.raviroza.listviewdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.core.view.get
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var cities = mutableListOf<String>("jamnagar","rajkot")
        //var images = arrayListOf<Int>(R.drawable.ic_baseline_send_24,R.drawable.ic_launcher_background)
        //var adapter = ArrayAdapter(this,android.R.layout.simple_list_item_1,cities)
        var adapter = ArrayAdapter(this,android.R.layout.simple_list_item_checked,cities)
        //var adapter = ArrayAdapter(this,R.layout.myrow, R.id.label , cities)

        lstData.adapter = adapter
        lstData.choiceMode = ListView.CHOICE_MODE_MULTIPLE

        lstData.setOnItemClickListener { parent, view, position, id ->

            //if(lstData.get(position).isSelected)
            Toast.makeText(this,cities[position] ,Toast.LENGTH_SHORT).show()

        }

        btnSend.setOnClickListener()
        {
            cities.add(edName.text.toString())
            adapter.notifyDataSetChanged()
        }
    }
}