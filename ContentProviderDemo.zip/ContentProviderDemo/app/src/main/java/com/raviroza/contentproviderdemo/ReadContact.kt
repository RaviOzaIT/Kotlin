package com.raviroza.contentproviderdemo

import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_read_contact.*

class ReadContact : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_read_contact)

        try {
            var uri : Uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            // Form an array specifying which columns to return.
            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            )
            val selection = null
            val selectionArgs = null
            val sortOrder = null

            val cursor = contentResolver.query (uri,projection,selection,selectionArgs,sortOrder)

            var item = ""
            var contacts = ArrayList<String>()
            if(cursor!=null) {
                while (cursor.moveToNext()) {
                    val name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME))
                    val number = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))
                    contacts.add(name+"\n"+number)
                }
            }
            listView1.adapter = ArrayAdapter(this,android.R.layout.simple_list_item_1,contacts)
        } catch (e: Exception)
        {
            Toast.makeText(this,e.toString(),Toast.LENGTH_SHORT).show()
            Log.e("rro",e.toString())
        }
    }
}