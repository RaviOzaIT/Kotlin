package com.raviroza.contentproviderdemo

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*

class ReadMedia : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        try {
            var uri : Uri = MediaStore.Audio.Media.INTERNAL_CONTENT_URI
            var cols = arrayOf(MediaStore.Audio.Media.TITLE,
                                MediaStore.Audio.Media.DURATION)

            val cursor = contentResolver.query (uri,cols,null,null,null)

            var item = ""
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    val title = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.TITLE))
                    val length = cursor.getString(cursor.getColumnIndex(MediaStore.Audio.Media.DURATION))
                    item += "Title : $title  | Length : " + length.toInt()/1000 + "seconds \n"
                }
            }
            this.txt1.text = item.toString()
        } catch (e: Exception) {
            Log.e("myerror",e.toString())
        }
    }
}