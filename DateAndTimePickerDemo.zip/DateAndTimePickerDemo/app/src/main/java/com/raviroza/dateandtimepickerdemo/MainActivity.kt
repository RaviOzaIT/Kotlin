package com.raviroza.dateandtimepickerdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        datePicker1.setOnDateChangedListener { view, year, monthOfYear, dayOfMonth ->
            try {
                txtDate.text = "Date is :  $dayOfMonth/${monthOfYear.toInt()+1}/$year "
            }
            catch (e:Exception)
            {
                Log.e("my-error",e.toString())
            }
        }

        timePicker1.setOnTimeChangedListener { view, hourOfDay, minute ->
            try {
                txtTime.text = "Time is : $hourOfDay:$minute"
            }
            catch (e:Exception)
            {
                Log.e("my-error",e.toString())
            }
        }
    }
}