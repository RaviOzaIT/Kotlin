package com.raviroza.telephonymanagerdemo

import android.app.NotificationManager
import android.content.Context
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.app.NotificationCompat
import android.telephony.TelephonyManager
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnNetworkState.setOnClickListener()
        {
            /* you will also need to add this permission in Manifest.
            <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" /> */

            val connectivityManager =
                getSystemService(Context.CONNECTIVITY_SERVICE)
                        as ConnectivityManager

            val activeNetworkInfo = connectivityManager.activeNetworkInfo
            var status = ""
            if(activeNetworkInfo != null) {
                status = "network : ${activeNetworkInfo.extraInfo}\n"
                status += "detail state : ${activeNetworkInfo.detailedState}\n"
                status += "is availabe : ${activeNetworkInfo.isAvailable}\n"
                status += "is connected : ${activeNetworkInfo.isConnected}"
            }
            txtNetworkState.text = status
        }
        btnTelephonyInfo.setOnClickListener()
        {
            //Calling the methods of TelephonyManager the returns the information
            // requires phone state permission in manifest file
            // <uses-permission android:name="android.permission.READ_PHONE_STATE" />

            try {
                val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

                val IMEINumber = tm.deviceId
                val subscriberID = tm.subscriberId
                val SIMSerialNumber = tm.simSerialNumber
                val networkCountryISO = tm.networkCountryIso
                val SIMCountryISO = tm.simCountryIso
                val softwareVersion = tm.deviceSoftwareVersion
                val voiceMailNumber = tm.voiceMailNumber

                //Get the phone type
                var strphoneType = ""

                val phoneType = tm.phoneType

                when (phoneType) {
                    TelephonyManager.PHONE_TYPE_CDMA -> strphoneType = "CDMA"
                    TelephonyManager.PHONE_TYPE_GSM -> strphoneType = "GSM"
                    TelephonyManager.PHONE_TYPE_NONE -> strphoneType = "NONE"
                }

                //getting information if phone is in roaming
                val isRoaming = tm.isNetworkRoaming

                var info = "Phone Details:\n"
                info += "\n IMEI Number:$IMEINumber"
                info += "\n SubscriberID:$subscriberID"
                info += "\n Sim Serial Number:$SIMSerialNumber"
                info += "\n Network Country ISO:$networkCountryISO"
                info += "\n SIM Country ISO:$SIMCountryISO"
                info += "\n Software Version:$softwareVersion"
                info += "\n Voice Mail Number:$voiceMailNumber"
                info += "\n Phone Network Type:$strphoneType"
                info += "\n In Roaming? :$isRoaming"

                txtTelephonyState.text = info
            }
            catch (e: SecurityException)
            {
                Log.e("myerror",e.toString())
            }

        }
    }
    fun getTelephonyInfo()
    {
        // requires phone state permission in manifest file
        // <uses-permission android:name="android.permission.READ_PHONE_STATE" />
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

            //Calling the methods of TelephonyManager the returns the information
            val IMEINumber = tm.deviceId
            val subscriberID = tm.subscriberId
            val SIMSerialNumber = tm.simSerialNumber
            val networkCountryISO = tm.networkCountryIso
            val SIMCountryISO = tm.simCountryIso
            val softwareVersion = tm.deviceSoftwareVersion
            val voiceMailNumber = tm.voiceMailNumber

            //Get the phone type
            var strphoneType = ""

            val phoneType = tm.phoneType

            when (phoneType) {
                TelephonyManager.PHONE_TYPE_CDMA -> strphoneType = "CDMA"
                TelephonyManager.PHONE_TYPE_GSM -> strphoneType = "GSM"
                TelephonyManager.PHONE_TYPE_NONE -> strphoneType = "NONE"
            }

            //getting information if phone is in roaming
            val isRoaming = tm.isNetworkRoaming

            var info = "Phone Details:\n"
            info += "\n IMEI Number:$IMEINumber"
            info += "\n SubscriberID:$subscriberID"
            info += "\n Sim Serial Number:$SIMSerialNumber"
            info += "\n Network Country ISO:$networkCountryISO"
            info += "\n SIM Country ISO:$SIMCountryISO"
            info += "\n Software Version:$softwareVersion"
            info += "\n Voice Mail Number:$voiceMailNumber"
            info += "\n Phone Network Type:$strphoneType"
            info += "\n In Roaming? :$isRoaming"
        }
        catch (e: SecurityException)
        {
            Log.e("myerror",e.toString())
        }
    }
    fun isNetworkConnected(): Boolean {

        /* you will also need to add this permission in Manifest.
       <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" /> */
        val connectivityManager =
                getSystemService(Context.CONNECTIVITY_SERVICE)
                        as ConnectivityManager

        val activeNetworkInfo = connectivityManager.activeNetworkInfo
        return activeNetworkInfo != null && activeNetworkInfo.isConnected
        return true

    }
}