package com.raviroza.optionmenudemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlin.system.exitProcess

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.nav_menu,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId)
        {
            R.id.navNew -> {
                Toast.makeText(this, "new is selected", Toast.LENGTH_SHORT).show()
            }
            R.id.navDelete  -> {
                Toast.makeText(this,"delete is selected",Toast.LENGTH_SHORT).show()
            }
            R.id.navExit -> {
                Toast.makeText(this,"exit is selected",Toast.LENGTH_SHORT).show()
            }
        }
/*
        if(item.itemId == R.id.navNew)
            txt1.text = "New : " + item.title
            //Toast.makeText(this,"new is selected",Toast.LENGTH_SHORT).show()
        else if(item.itemId == R.id.navDelete)
            txt1.text = "Delete : " + item.title
            //Toast.makeText(this,"delete is selected",Toast.LENGTH_SHORT).show()
        else if(item.itemId == R.id.navExit) {
            Toast.makeText(this,"exit is selected",Toast.LENGTH_SHORT).show()
            txt1.text = "Exit : " + item.title
            exitProcess(1)
        }*/
        return super.onOptionsItemSelected(item)
    }
}