package com.raviroza.gridviewdemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.GridView
import android.widget.ListView
import android.widget.Toast
import androidx.core.util.forEach
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var cities = resources.getStringArray(R.array.cities)

        //var adapter = ArrayAdapter(this,android.R.layout.simple_list_item_1 ,cities)
        var adapter = ArrayAdapter(this,android.R.layout.simple_list_item_checked ,cities)

        gridView1.adapter = adapter
        gridView1.choiceMode = GridView.CHOICE_MODE_MULTIPLE


        gridView1.setOnItemClickListener { parent, view, position, id ->
            Toast.makeText(this,cities[position],Toast.LENGTH_SHORT).show()
        }

        btnSelected.setOnClickListener()
        {
            val selected = gridView1.checkedItemPositions
            var t = ""
            for(i in 0..selected.size())
            {
                val x = selected.keyAt(i)
                if(selected.valueAt(i))
                {
                    t += adapter.getItem(x) + "\n"
                }
            }
            Toast.makeText(this,t.toString(),Toast.LENGTH_SHORT).show()
        }
    }
}