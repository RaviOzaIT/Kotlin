package com.raviroza.drawingdemo

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)
        setContentView(MyView(this))
    }
    class MyView(context: Context?) : View(context)
    {
        override fun onDraw(canvas: Canvas)
        {
            canvas.drawColor(Color.BLUE)
            // flat color effect
            //var paint:Paint = Paint();

            // smoothing color effect
            var paint:Paint = Paint(Paint.ANTI_ALIAS_FLAG)
            paint.setColor(Color.WHITE)

            // paint styles
            // only outlines
            paint.style = Paint.Style.STROKE


            paint.textSize = 50f
            paint.textAlign = Paint.Align.LEFT
            canvas.drawText("LEFT",canvas.width/2f,50f,paint)
            canvas.drawLine(0f,30f,canvas.width/1f,30f, paint)

            // fill
            paint.style = Paint.Style.FILL

            paint.textAlign = Paint.Align.CENTER
            canvas.drawText("CENT",canvas.width/2f,100f,paint)

            paint.textAlign = Paint.Align.RIGHT
            canvas.drawText("RIGH",canvas.width/2f,150f,paint)

            canvas.drawCircle(
                    canvas.width/2f,
                    canvas.height/2f,
                    canvas.width/3f,
                    paint)
        }
    }
}